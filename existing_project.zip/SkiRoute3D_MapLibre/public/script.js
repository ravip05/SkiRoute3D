
const map = new maplibregl.Map({
  container: 'map',
  style: 'https://demotiles.maplibre.org/style.json',
  center: [-122.4194, 37.7749],
  zoom: 13,
  pitch: 60,
  bearing: -10,
  antialias: true
});

map.addControl(new maplibregl.NavigationControl());

let startMarker = null;
let endMarker = null;
let routeLine = null;
let gpsMarker = null;

const gpsBtn = document.createElement('button');
gpsBtn.textContent = '📍 Use My Location';
gpsBtn.className = 'gps-btn';
document.body.appendChild(gpsBtn);

gpsBtn.onclick = () => {
  if ('geolocation' in navigator) {
    navigator.geolocation.getCurrentPosition(pos => {
      const { latitude, longitude } = pos.coords;
      map.flyTo({ center: [longitude, latitude], zoom: 14 });

      if (gpsMarker) gpsMarker.remove();
      gpsMarker = new maplibregl.Marker({ color: 'deepskyblue' })
        .setLngLat([longitude, latitude])
        .setPopup(new maplibregl.Popup().setText('You are here'))
        .addTo(map);
    }, err => alert('Failed to get location'));
  } else {
    alert('Geolocation is not supported');
  }
};

map.on('click', function (e) {
  const coords = [e.lngLat.lng, e.lngLat.lat];

  if (!startMarker) {
    startMarker = new maplibregl.Marker({ color: 'green' })
      .setLngLat(coords)
      .addTo(map);
  } else if (!endMarker) {
    endMarker = new maplibregl.Marker({ color: 'red' })
      .setLngLat(coords)
      .addTo(map);
    drawRoute(startMarker.getLngLat(), endMarker.getLngLat());
  } else {
    startMarker.remove();
    endMarker.remove();
    if (routeLine) {
      map.removeLayer('route');
      map.removeSource('route');
    }
    startMarker = new maplibregl.Marker({ color: 'green' })
      .setLngLat(coords)
      .addTo(map);
    endMarker = null;
  }
});

function drawRoute(start, end) {
  const route = {
    type: 'Feature',
    geometry: {
      type: 'LineString',
      coordinates: [
        [start.lng, start.lat],
        [end.lng, end.lat]
      ]
    }
  };

  map.addSource('route', {
    type: 'geojson',
    data: route
  });

  map.addLayer({
    id: 'route',
    type: 'line',
    source: 'route',
    layout: {
      'line-join': 'round',
      'line-cap': 'round'
    },
    paint: {
      'line-color': '#ff7e5f',
      'line-width': 4
    }
  });

  routeLine = route;
}

const amenities = [
  { name: 'Restroom', coords: [-122.423, 37.775], color: 'blue' },
  { name: 'Ski Patrol', coords: [-122.417, 37.772], color: 'orange' },
  { name: 'Lodge', coords: [-122.419, 37.778], color: 'purple' }
];

amenities.forEach(poi => {
  new maplibregl.Marker({ color: poi.color })
    .setLngLat(poi.coords)
    .setPopup(new maplibregl.Popup().setText(poi.name))
    .addTo(map);
});

map.on('load', () => {
  map.addLayer({
    id: 'snow-overlay',
    type: 'fill',
    source: {
      type: 'geojson',
      data: {
        type: 'FeatureCollection',
        features: [
          {
            type: 'Feature',
            geometry: {
              type: 'Polygon',
              coordinates: [[
                [-122.422, 37.777],
                [-122.420, 37.777],
                [-122.420, 37.775],
                [-122.422, 37.775],
                [-122.422, 37.777]
              ]]
            },
            properties: { snowDepth: 'Heavy Snow' }
          }
        ]
      }
    },
    paint: {
      'fill-color': '#a7f3d0',
      'fill-opacity': 0.3
    }
  });
});
