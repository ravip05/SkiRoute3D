# SkiRoute3D 🏔️ (MapLibre Edition)

A browser-based app that helps skiers find optimal paths with 3D terrain visualization using MapLibre.

## Features
- Interactive 3D map (no token required)
- Start/end route planning
- Real-time GPS simulation
- Amenity markers + snow overlay

## Setup
1. Open `index.html` in your browser
2. Or run `npx serve public` to test it on localhost

---

No credit card, no API key. 100% open source!
